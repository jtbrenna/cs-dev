
<!-- SUB-BANNER INCLUDE -->
<?php
include('_undergradsubbanner.html');
?>

<!-- RIGHT HAND NAVIGATION BOX INCLUDE -->
<?php
include('_undergradsuppnav.html');
?>

<?php
require_once "{$_SERVER['UVMMAGIC']}/plugins/courses/Course_Catalogue_Web.php";
$course =& new Course_Catalogue_Web($debug);
$course->setDefaultTerm($default_term);
$_REQUEST['category']='CS';
print $course->browse($_REQUEST);
?>
