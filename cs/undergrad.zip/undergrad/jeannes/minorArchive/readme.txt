The minor actually changed in 07_08 but never made the catalog changes.
It was approved to be what is given for 08_09.