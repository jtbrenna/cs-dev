
<!-- SUB-BANNER INCLUDE -->
<?php
include('_undergradsubbanner.html');
?>

<!-- RIGHT HAND NAVIGATION BOX INCLUDE -->
<?php
include('_undergradsuppnav.html');
?>

<h3>Minor / Certificate</h3>

<h4>Minor in Computer Science</h4>
<p>
The Computer Science Minor is a cross-college minor available to all UVM students. The requirements are 18 credits of Computer Science to include:
</p>
<ul>
<li>100 or 103</li>
<li>104</li>
<li>3 additional credits at 100 level or above</li>
</ul>
<p>
Some Computer Science courses require additional prerequisites.
</p>
 
<br />

<h4>Certificate in Computer Software</h4>
<p>
The Department of Computer Science and the Division of Continuing Education offer a non-degree <a href="http://learn.uvm.edu/?Page=computer.html">Certificate in Computer Software</a> that requires five courses (at least 15 credits) in approved CS courses at UVM.
</p>
<p>
The certificate program offers a flexible selection of courses to meet individual needs. For example, one can design a program in preparation for admission to the Master of Science program for students whose undergraduate degree is from another academic discipline.
</p>
<p>
Contact Alison Pechenick (<a href="mailto:Alison.Pechenick@uvm.edu">Alison.Pechenick@uvm.edu</a>) for more information.
</p>